# ModelisationL3
Projet L3 modélisation (Travail sur les images, réduction d'images en supprimant pixels)

# Informations
* Le jar est dans le dossier jar/
* Les sources dans src/
* Les images de test et les images de test réduites sont dans res/

# Répartition du travail
* Guillaume : writepgm, interest, tograph, reduce_width
* Simon : DFS, tritopo, Bellman, del_pix_column


# Usage
java -jar seamcarving.jar <pgm source> <pgm destination> <nombre d'itération>
